<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CourseTrendz | CTZ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css" />
    <link rel="stylesheet" href="assets/css/global.css">
    <script defer src="https://use.fontawesome.com/releases/v5.14.0/js/all.js"></script>
</head>

<body>
    <!-- navigation started -->
    <nav class="navbar is-info">
        <div class="container">
            <div class="navbar-brand">
                <a class="navbar-item" href="/">
                    <h1 class="has-text-weight-medium is-size-4">CourseTrendz</h1>
                </a>
                <span class="navbar-burger burger" data-target="navbarMenuHeroB">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </div>
            <div id="navbarMenuHeroB" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item is-active" href="/"> Home </a>
                    <a class="navbar-item is-primary is-large modal-button" data-target="signinModal">Signin</a>
                    <a class="navbar-item"> Signup </a>
                </div>
            </div>
        </div>
    </nav>
    <!-- navigation ended here -->
    <!-- main section starts -->
    <section class="hero is-info is-fullheight-with-navbar">
        <div class="hero-body">
            <div class="container has-text-centered">
                <h1 class="title">Learn Without wories</h1>
                <p class="subtitle">Get Online courses for free</p>
                <p>
                <strong>
                    <a href="courses.php">Browse All</a>
                </strong>
                </p>
            </div>
        </div>
    </section>
     <!-- main section ends here -->
    <!-- sign in modal -->
    <div class="modal" id="signinModal">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
            <p class="modal-card-title">Modal title</p>
            <button class="delete" aria-label="close"></button>
            </header>
            <section class="modal-card-body">
            <!-- Content ... -->
            </section>
            <footer class="modal-card-foot">
            <button class="button is-success">Save changes</button>
            <button class="button">Cancel</button>
            </footer>
        </div>
    </div>
    <!-- JS scripts starts -->
    <script src="assets/js/main.js"></script>
    <!-- JS scripts ends here -->
</body>
</html>